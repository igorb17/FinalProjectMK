<?php
define("DB_HOST", "localhost");
define("DB_USER", "iammonir_user");
define("DB_PASS", "lBQ(CSe+7dBG");
define("DB_NAME", "iammonir_shop");
